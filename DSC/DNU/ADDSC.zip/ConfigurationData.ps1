@{
	AllNodes = @(
	@{
		NodeName                    = '*'
		PSDscAllowPlainTextPassword = $true
	 }
        )
}