﻿Configuration DNSServer
{
 
    [CmdletBinding()]

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xDNSServer, xDSCFirewall
 
    Node 'localhost'
    {

#            LocalConfigurationManager
#            {
#                ConfigurationMode = 'ApplyOnly'
#                RebootNodeIfNeeded = $true
#                ActionAfterReboot = 'ContinueConfiguration'
#                AllowModuleOverwrite = $true
#            }

            xDSCFirewall DisablePublicFW 
            {
                Ensure = 'Absent'
                Zone = 'Public'
            }

            xDSCFirewall DisablePrivateFW 
            {
                Ensure = 'Absent'
                Zone = 'Private'
            }

            xDSCFirewall DisableDomainFW 
            {
                Ensure = 'Absent'
                Zone = 'Domain'
            }

            WindowsFeature RSAT_DNS
            { 
                Ensure = 'Present'
                Name = 'DNS'
            }

            WindowsFeature RSAT_DNS
            { 
                Ensure = 'Present'
                Name = 'RSAT-DNS-Server'
            }
 
 
            xDnsServerPrimaryZone ConfigureDNS 
            { 
                Ensure = 'Present'
                Name = 'SQLHAU.LAB'
                DynamicUpdate = 'NonsecureAndSecure'
                DependsOn = '[WindowsFeature]DNS'
            }

    }

}
